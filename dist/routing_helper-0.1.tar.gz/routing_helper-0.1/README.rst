routing_helper
--------------

Package to provide helper functions to the sail_route.jl package.
