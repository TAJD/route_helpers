from markdown import markdown

def joke():
    return (u'Wenn ist das Nunst\u00fcck git un Slotermeyer?')
